#!/bin/bash
#SBATCH --account=aip-boyuwang
#SBATCH --job-name=xev_c100_simclr_kmeans1
#SBATCH --time=0-00:20:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --gres=gpu:l40s:1
#SBATCH --output=slurm-%x-%j.out

set -euo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the MKDT project directory}}"
source "$PROJECT_ROOT/benchmarks/cross_downstream/environment.sh"
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__TinyImageNet_lbl1"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__TinyImageNet_lbl1/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target TinyImageNet \
    --target-cache "$CROSS_RUN_ROOT/targets/TinyImageNet.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 1 --probe-epochs 500 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__TinyImageNet_lbl5"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__TinyImageNet_lbl5/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target TinyImageNet \
    --target-cache "$CROSS_RUN_ROOT/targets/TinyImageNet.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 5 --probe-epochs 300 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CIFAR10_lbl1"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CIFAR10_lbl1/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target CIFAR10 \
    --target-cache "$CROSS_RUN_ROOT/targets/CIFAR10.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 1 --probe-epochs 500 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CIFAR10_lbl5"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CIFAR10_lbl5/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target CIFAR10 \
    --target-cache "$CROSS_RUN_ROOT/targets/CIFAR10.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 5 --probe-epochs 300 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Aircraft_lbl1"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Aircraft_lbl1/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target Aircraft \
    --target-cache "$CROSS_RUN_ROOT/targets/Aircraft.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 1 --probe-epochs 500 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Aircraft_lbl5"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Aircraft_lbl5/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target Aircraft \
    --target-cache "$CROSS_RUN_ROOT/targets/Aircraft.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 5 --probe-epochs 300 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CUB2011_lbl1"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CUB2011_lbl1/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target CUB2011 \
    --target-cache "$CROSS_RUN_ROOT/targets/CUB2011.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 1 --probe-epochs 500 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CUB2011_lbl5"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__CUB2011_lbl5/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target CUB2011 \
    --target-cache "$CROSS_RUN_ROOT/targets/CUB2011.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 5 --probe-epochs 300 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Dogs_lbl1"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Dogs_lbl1/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target Dogs \
    --target-cache "$CROSS_RUN_ROOT/targets/Dogs.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 1 --probe-epochs 500 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Dogs_lbl5"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Dogs_lbl5/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target Dogs \
    --target-cache "$CROSS_RUN_ROOT/targets/Dogs.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 5 --probe-epochs 300 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Flowers_lbl1"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Flowers_lbl1/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target Flowers \
    --target-cache "$CROSS_RUN_ROOT/targets/Flowers.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 1 --probe-epochs 500 --runs 10
mkdir -p "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Flowers_lbl5"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py evaluate \
    --output "$CROSS_RUN_ROOT/evaluations/cifar100_ResNet18_simclr_kmeans_size1__Flowers_lbl5/job_$SLURM_JOB_ID" \
    --source CIFAR100 --target Flowers \
    --target-cache "$CROSS_RUN_ROOT/targets/Flowers.pt" --encoder-dir "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_simclr_kmeans_size1" \
    --method kmeans --ssl-method simclr \
    --subset-percentage 1 --ssl-epochs 5000 \
    --label-percentage 5 --probe-epochs 300 --runs 10
