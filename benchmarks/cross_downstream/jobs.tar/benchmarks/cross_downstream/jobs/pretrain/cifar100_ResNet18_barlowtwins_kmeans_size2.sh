#!/bin/bash
#SBATCH --account=aip-boyuwang
#SBATCH --job-name=xpre_c100_barlowtwins_kmeans2
#SBATCH --time=0-06:15:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --gres=gpu:l40s:1
#SBATCH --output=slurm-%x-%j.out

set -euo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the MKDT project directory}}"
source "$PROJECT_ROOT/benchmarks/cross_downstream/environment.sh"
mkdir -p "$CROSS_RUN_ROOT/encoders"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py pretrain \
    --source CIFAR100 --source-cache "${CIFAR100_SOURCE_CACHE}" \
    --selection-dir "${CIFAR100_SELECTION_DIR}" \
    --output "$CROSS_RUN_ROOT/encoders/cifar100_ResNet18_barlowtwins_kmeans_size2" --runs 10 \
    --method kmeans --ssl-method barlowtwins --subset-percentage 2 \
    --ssl-epochs 8000
