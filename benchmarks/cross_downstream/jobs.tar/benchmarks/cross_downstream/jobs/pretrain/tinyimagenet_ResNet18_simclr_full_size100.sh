#!/bin/bash
#SBATCH --account=aip-yiweilu
#SBATCH --job-name=xpre_tiny_simclr_full100
#SBATCH --time=0-22:40:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --gres=gpu:l40s:1
#SBATCH --output=slurm-%x-%j.out

set -euo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the MKDT project directory}}"
source "$PROJECT_ROOT/benchmarks/cross_downstream/environment.sh"
mkdir -p "$CROSS_RUN_ROOT/encoders"
srun --unbuffered python3 benchmarks/benchmark_cross_dataset.py pretrain \
    --source TinyImageNet --source-cache "${TINYIMAGENET_SOURCE_CACHE}" \
    --selection-dir "${TINYIMAGENET_SELECTION_DIR}" \
    --output "$CROSS_RUN_ROOT/encoders/tinyimagenet_ResNet18_simclr_full_size100" --runs 10 \
    --method full --ssl-method simclr --subset-percentage 100 \
    --ssl-epochs 300
