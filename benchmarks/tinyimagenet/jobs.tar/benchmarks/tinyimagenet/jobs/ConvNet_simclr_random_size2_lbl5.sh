#!/bin/bash
#SBATCH --account=aip-boyuwang
#SBATCH --job-name=tiny_ConvNet_simclr_random_size2_lbl5
#SBATCH --time=0-01:40:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --gres=gpu:l40s:1
#SBATCH --output=slurm-%x-%j.out

set -euo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the MKDT project directory}}"
source "$PROJECT_ROOT/benchmarks/main/environment.sh"
CONFIG_ID=ConvNet_simclr_random_size2_lbl5
OUTPUT="$MAIN_RUN_ROOT/$CONFIG_ID/job_$SLURM_JOB_ID"
mkdir -p "$MAIN_RUN_ROOT/$CONFIG_ID"
srun --unbuffered python3 benchmarks/benchmark_dataset.py run \
    --dataset TinyImageNet --target-cache "$TARGET_CACHE" \
    --output "$OUTPUT" --selection-dir "$SELECTION_DIR" \
    --runs 10 --seed-start 0 --method random --model ConvNet \
    --ssl-method simclr --subset-percentage 2 --label-percentage 5 \
    --ssl-epochs 4000 --probe-epochs 300
