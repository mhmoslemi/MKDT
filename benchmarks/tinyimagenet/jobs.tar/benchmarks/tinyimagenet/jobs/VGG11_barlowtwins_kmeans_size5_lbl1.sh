#!/bin/bash
#SBATCH --account=aip-boyuwang
#SBATCH --job-name=tiny_VGG11_barlowtwins_kmeans_size5_lbl1
#SBATCH --time=0-06:55:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --gres=gpu:l40s:1
#SBATCH --output=slurm-%x-%j.out

set -euo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the MKDT project directory}}"
source "$PROJECT_ROOT/benchmarks/main/environment.sh"
CONFIG_ID=VGG11_barlowtwins_kmeans_size5_lbl1
OUTPUT="$MAIN_RUN_ROOT/$CONFIG_ID/job_$SLURM_JOB_ID"
mkdir -p "$MAIN_RUN_ROOT/$CONFIG_ID"
srun --unbuffered python3 benchmarks/benchmark_dataset.py run \
    --dataset TinyImageNet --target-cache "$TARGET_CACHE" \
    --output "$OUTPUT" --selection-dir "$SELECTION_DIR" \
    --runs 10 --seed-start 0 --method kmeans --model VGG11 \
    --ssl-method barlowtwins --subset-percentage 5 --label-percentage 1 \
    --ssl-epochs 6000 --probe-epochs 500
