#!/bin/bash
#SBATCH --account=aip-yiweilu
#SBATCH --job-name=ours_CIFAR10_VGG11_simclr_ours_size1_lbl1
#SBATCH --time=0-01:05:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=15G
#SBATCH --gres=gpu:l40s:1
set -euo pipefail
cd "$OURS_CODE_ROOT"
module load StdEnv/2023 python/3.11.5
source "${VENV_ACTIVATE:-$HOME/ENV/bin/activate}"
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1
export HF_HOME="$SCRATCH/hf_cache" XDG_CACHE_HOME="$SCRATCH/cache"
srun --unbuffered python3 benchmarks/benchmark_ours.py evaluate --batch "$OURS_BATCH" --model VGG11 --ssl-method simclr --subset-percentage 1 --ssl-epochs 1200 --target CIFAR10 --label-percentage 1 --probe-epochs 200 --data-path "$DATA_ROOT" --output "$OURS_BATCH/evaluations/CIFAR10_VGG11_simclr_ours_size1_lbl1/job_$SLURM_JOB_ID"
