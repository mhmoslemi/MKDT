#!/bin/bash
#SBATCH --account=aip-boyuwang
#SBATCH --job-name=ours_tables
#SBATCH --time=0-00:05:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
set -euo pipefail
cd "$OURS_CODE_ROOT"
module load StdEnv/2023 python/3.11.5
source "${VENV_ACTIVATE:-$HOME/ENV/bin/activate}"
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1
export HF_HOME="$SCRATCH/hf_cache" XDG_CACHE_HOME="$SCRATCH/cache"
python3 benchmarks/benchmark_ours.py report --batch "$OURS_BATCH" --project-root "$PROJECT_ROOT"
