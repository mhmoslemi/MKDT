#!/bin/bash
#SBATCH --account=aip-boyuwang
#SBATCH --job-name=ours_syn_size2
#SBATCH --time=0-02:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=15G
#SBATCH --gres=gpu:l40s:1
set -euo pipefail
cd "$OURS_CODE_ROOT"
module load StdEnv/2023 python/3.11.5
source "${VENV_ACTIVATE:-$HOME/ENV/bin/activate}"
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1
export HF_HOME="$SCRATCH/hf_cache" XDG_CACHE_HOME="$SCRATCH/cache"
[[ ! -e "$OURS_BATCH/synthetic/size2" ]]
srun --unbuffered python3 OT-SSL-DD/mina_IF.py --percentage 2 --data_path "$DATA_ROOT" --save_path "$OURS_BATCH/synthetic/size2"
