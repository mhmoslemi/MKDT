#!/bin/bash
#SBATCH --account=aip-yiweilu
#SBATCH --job-name=c100_VGG11_barlowtwins_full_size100_lbl1
#SBATCH --time=0-03:30:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --gres=gpu:l40s:1
#SBATCH --output=slurm-%x-%j.out

set -euo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the MKDT project directory}}"
source "$PROJECT_ROOT/benchmarks/main/environment.sh"
CONFIG_ID=VGG11_barlowtwins_full_size100_lbl1
OUTPUT="$MAIN_RUN_ROOT/$CONFIG_ID/job_$SLURM_JOB_ID"
mkdir -p "$MAIN_RUN_ROOT/$CONFIG_ID"
srun --unbuffered python3 benchmarks/benchmark_dataset.py run \
    --dataset CIFAR100 --target-cache "$TARGET_CACHE" \
    --output "$OUTPUT" --selection-dir "$SELECTION_DIR" \
    --runs 10 --seed-start 0 --method full --model VGG11 \
    --ssl-method barlowtwins --subset-percentage 100 --label-percentage 1 \
    --ssl-epochs 300 --probe-epochs 500
